<?php
/* MODEL */
Class ModelProva extends CI_Model{
    public function __construct(){
        parent::__construct();
        $this->load->database();
    }
    public function inserirDades(){
        $sql="insert into noticia(titol,cos,codiSeccio) values('Noticia CodeIgniter','Cos noticia',1)";
        $this->db->query($sql);
        $num_files=$this->db->affected_rows();
        return $num_files;
    }
    public function updateDades($oldSeccio,$newSeccio){
        $sql="update noticia set codiSeccio=$newSeccio where codiSeccio=$oldSeccio";
        $this->db->query($sql);
        $num_files=$this->db->affected_rows();
        return $num_files;
    }
    public function retornaDades($sql){

        $resultat = $this->db->query($sql);
        $dades = $resultat->result_array();
        return $dades;
    }
}
