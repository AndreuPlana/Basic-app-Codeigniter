<HTML>
<BODY>
<?php
/* VISTA */
if(!empty($resultat)){
    echo "<h1>Sentencia executada correctament</h1>";
    echo "FILES AFECTADES: $resultat";


}else{
    echo "<h2>Error executant la sentencia</h2>";
}
foreach ($select as $item =>$fila)
{
    foreach ($fila as $item2=>$camp)
    {
        echo $camp;
        echo "<br>";
    }
}

?>
</BODY>
</HTML>