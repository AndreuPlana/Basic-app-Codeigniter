<html>
<head><title>ProvaVista</title></head>
<body>
<h1><?php echo $text; ?></h1>
</body>
</html>
