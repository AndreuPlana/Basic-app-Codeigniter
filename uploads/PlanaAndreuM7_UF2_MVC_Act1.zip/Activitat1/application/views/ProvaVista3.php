<html>
<head>ProvaVista2</head>
<body>
<h1>Variable 1 <?php echo $par1?></h1>
<h1>Variable 2 <?php echo $par2?></h1>
</body>
</html>