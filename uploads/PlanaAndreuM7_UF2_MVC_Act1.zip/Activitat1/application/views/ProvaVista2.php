<html>
<head>ProvaVista2</head>
<body>
<h1><?php echo $text2?></h1>
</body>
</html>