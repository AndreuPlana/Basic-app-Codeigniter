<?php
class ProvaControlador extends CI_Controller {
    public function index(){

        $data['text'] = "Hello World";
        $this->load->view('ProvaVista',$data);

        //Per a accedir al controlador es localhost:8888/CodeIgniter/index.php/ProvaControlador
    }
    public function metode2(){
        $data['text2'] = "Hello World Metode 2";
        $this->load->view('ProvaVista2',$data);
    }
    public function metode3($par1, $par2){
        $data['par1'] = $par1;
        $data['par2'] = $par2;
        $this->load->view('ProvaVista3',$data);
    }
}

