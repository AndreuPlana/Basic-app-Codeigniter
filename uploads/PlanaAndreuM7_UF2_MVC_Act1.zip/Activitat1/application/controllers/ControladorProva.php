<?php
/* CONTROLADOR */
Class ControladorProva extends CI_Controller{
    public function _output($dades){
        echo $dades;
    }
    public function index(){
        $this->load->model('ModelProva');
        $dades['resultat']=$this->ModelProva->inserirDades();
        $this->load->view('VistaProva',$dades);
    }
    public function updateDades($var1,$var2){
        $this->load->model('ModelProva');
        $dades['resultat']=$this->ModelProva->updateDades($var1,$var2);
        $this->load->view('VistaProva',$dades);
    }

    public function mostrarDades(){
        $this->load->model('ModelProva');
        $sql="select * from noticia";
        $dades ['select'] = $this->ModelProva->retornaDades($sql);
        $this->load->view('VistaProva',$dades);
    }
}
