public class CPersona {
    private String nom, cognom,segonCognom;
    private int numeroSecret;
    
    
    public CPersona(String nom, String cognom, String segonCognom, int numeroSecret){
        this.nom=nom;
        this.cognom=cognom;
        this.segonCognom=segonCognom;
        this.numeroSecret=numeroSecret;
    }
    public CPersona(){
        this("","","",0);
    }
    public CPersona(CPersona obj){
        this(obj.nom,obj.cognom,obj.segonCognom,obj.numeroSecret);
    }
    
    
    public void setNom(String d){
        this.nom=d;
    }
    public String getNom(){
        return this.nom;
    }
    public void setCognom(String d){
        this.cognom=d;
    }
    public String getCognom(){
        return this.cognom;
    }
    public void setsegonCognom(String d){
        this.segonCognom=d;
    }
    public String getsegonCognom(){
        return this.segonCognom;
    }
    public int getnumeroSecret(){
        return this.numeroSecret;
    }

    public void setNumeroSecret(int numeroSecret) {
        this.numeroSecret = numeroSecret;
    }
    
}

