public class CCompteBancari {
    int numero;
    long saldo;
    CPersona propietari;
    
    
    public CCompteBancari( CPersona propietari){
        this.numero=seguentCompte;
        this.saldo=saldoInicial;
        this.propietari=propietari;
        seguentCompte++;
    }
    public CCompteBancari(CCompteBancari obj){
        this(obj.propietari);
    }
    
    
    private static int seguentCompte=1234;
    private static long saldoInicial=100;
    
    public long getseguentCompte(){
        return seguentCompte;
    }
    
    public long getsaldoInicial(){
        return saldoInicial;
    }
    
    public static void modificarSaldoInicial(long d){
        CCompteBancari.saldoInicial=d;
    }
    public long consultarSaldo(){
        return this.saldo;
    }
    
    public boolean numeroSecret(int d){
        if(d==propietari.getnumeroSecret()){
            return true;
        }else{
            return false;
        }
    }
    
    public boolean ingressar(long q, int numsecret){
        if(numsecret==propietari.getnumeroSecret()){
            this.saldo=this.saldo+q;
            return true;
        }else{
            return false;
        }
    }
    
    public boolean extreure (long q,int numsecret){
         if(numsecret==propietari.getnumeroSecret()){
            this.saldo=this.saldo-q;
            return true;
        }else{
            return false;
        }
    }

    public int getNumero() {
        return this.numero;
    }

    public long getSaldo() {
        return this.saldo;
    }

    public CPersona getPropietari() {
        return this.propietari;
    }
    public void eliminar(){
        this.numero=0;
        this.saldo=0;
        this.propietari=null;
    }
    

    
    
}